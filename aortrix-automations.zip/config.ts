
export const APP_CONFIG = {
  company: {
    name: "Aortrix Automations",
    logoText: "Aortrix ",
    logoAccent: "Automations",
    tagline: "You focus on work - automation handles the rest",
    heroHeadline: "We Build",
    description: "Aortrix Automations helps visionary brands transform complex challenges into elegant, high-performance digital solutions.",
    email: "support@aortrix.com",
    phone: "+91 7034690881",
    address: "Calicut, Kerala",
    social: {
      twitter: "#",
      linkedin: "#",
      instagram: "https://www.instagram.com/aortrixautomations/"
    }
  },
  aiConsultant: {
    name: "DAAN",
    role: "Senior Technical Product Manager",
    welcomeMessage: "Hello, I am a new client looking to start a project.",
    systemInstruction: `
You are DAAN, a Senior Technical Product Manager at Aortrix Automations.
Your goal is to interview a potential client (the user) to gather requirements for their automation or software project.
Ask relevant, probing questions one by one to understand their:
1. Industry and Target Audience
2. Core Business Goals (e.g., lead gen, sales, brand awareness)
3. Specific Automation Needs (CRM, Email, Workflows)
4. Budget and Timeline expectations

Be professional, concise, and enthusiastic. Start by asking what kind of project they are envisioning today.
Keep your responses relatively short (under 100 words) to keep the conversation flowing.
`
  },
  stats: {
    projects: "150+",
    retention: "98%",
    awards: "12"
  },
  services: [
    {
      id: "web",
      title: "Web Development",
      description: "High-performance websites built with React and Next.js that convert visitors into customers.",
      icon: "Monitor"
    },
    {
      id: "ai",
      title: "AI Integration",
      description: "Leverage modern LLMs to automate workflows and enhance user interaction.",
      icon: "Cpu"
    },
    {
      id: "marketing",
      title: "Digital Marketing",
      description: "Send automated messages and outperform competitors.",
      icon: "BarChart"
    },
    {
      id: "crm",
      title: "CRM Solutions",
      description: "Maintain customer relations and increase revenue with automated CRM workflows.",
      icon: "Smartphone"
    }
  ]
};
