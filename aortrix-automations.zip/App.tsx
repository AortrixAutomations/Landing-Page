import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Services from './components/Services';
import Consultant from './components/Consultant';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { Section } from './types';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>(Section.HERO);

  const scrollToSection = (section: Section) => {
    setActiveSection(section);
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-dark-900 text-white selection:bg-brand-500 selection:text-white">
      <Navigation activeSection={activeSection} scrollToSection={scrollToSection} />
      
      <main>
        <div id={Section.HERO}>
          <Hero scrollToSection={scrollToSection} />
        </div>
        <div id={Section.SERVICES}>
          <Services />
        </div>
        <div id={Section.CONSULTANT}>
          <Consultant />
        </div>
        <div id={Section.ABOUT}>
          <About />
        </div>
        <div id={Section.CONTACT}>
          <Contact />
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default App;