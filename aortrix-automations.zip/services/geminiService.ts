import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { APP_CONFIG } from "../config";

const apiKey = process.env.API_KEY || '';

// Initialize Gemini
let ai: GoogleGenAI | null = null;

try {
  if (apiKey) {
    ai = new GoogleGenAI({ apiKey: apiKey });
  }
} catch (error) {
  console.error("Failed to initialize GoogleGenAI", error);
}

export const createChatSession = (): Chat | null => {
  if (!ai) return null;

  try {
    return ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: APP_CONFIG.aiConsultant.systemInstruction,
        temperature: 0.7,
      },
    });
  } catch (error) {
    console.error("Error creating chat session:", error);
    return null;
  }
};

export const sendMessageToGemini = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "I apologize, I didn't catch that. Could you rephrase?";
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    return "I'm having trouble connecting to my creative matrix right now. Please try again later.";
  }
};