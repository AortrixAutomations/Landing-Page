import React from 'react';
import { Monitor, Smartphone, Cpu, BarChart, Code, Globe, LucideIcon } from 'lucide-react';
import { APP_CONFIG } from '../config';

const iconMap: Record<string, LucideIcon> = {
  "Monitor": Monitor,
  "Smartphone": Smartphone,
  "Cpu": Cpu,
  "BarChart": BarChart,
  "Code": Code,
  "Globe": Globe
};

const Services: React.FC = () => {
  return (
    <section className="py-24 bg-dark-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Our Expertise</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We combine cutting-edge technology with human-centric design to deliver measurable results.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {APP_CONFIG.services.map((service, index) => {
            const Icon = iconMap[service.icon] || Code;
            return (
              <div 
                key={index} 
                className="group p-8 bg-white/5 border border-white/5 rounded-2xl hover:bg-white/10 hover:border-brand-500/30 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="mb-6 p-4 bg-white/5 rounded-xl inline-block group-hover:bg-brand-500/20 transition-colors">
                  <Icon className={`w-8 h-8 ${index % 2 === 0 ? 'text-brand-400' : 'text-purple-400'}`} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-brand-300 transition-colors">{service.title}</h3>
                <p className="text-gray-400 leading-relaxed group-hover:text-gray-300">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;