
import React, { useState } from 'react';
import { Mail, MapPin, Phone, Send } from 'lucide-react';
import { APP_CONFIG } from '../config';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct mailto link
    const subject = `New Project Inquiry from ${formData.firstName} ${formData.lastName}`;
    const body = `Name: ${formData.firstName} ${formData.lastName}%0D%0AEmail: ${formData.email}%0D%0A%0D%0AMessage:%0D%0A${formData.message}`;
    
    // Open default email client
    window.location.href = `mailto:${APP_CONFIG.company.email}?subject=${encodeURIComponent(subject)}&body=${body}`;
  };

  return (
    <section className="py-24 bg-[#050914] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Let's Build the Future</h2>
            <p className="text-gray-400 mb-12">
              Ready to start your next project? Fill out the form or use the AI Consultant above to draft your requirements first.
            </p>
            
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center text-brand-400">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-white font-bold text-lg">Headquarters</h4>
                  <p className="text-gray-500">{APP_CONFIG.company.address}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center text-brand-400">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-white font-bold text-lg">Email Us</h4>
                  <p className="text-gray-500">{APP_CONFIG.company.email}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center text-brand-400">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-white font-bold text-lg">Call Us</h4>
                  <p className="text-gray-500">{APP_CONFIG.company.phone}</p>
                </div>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="bg-white/5 p-8 rounded-3xl border border-white/5 space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">First Name</label>
                <input 
                  type="text" 
                  name="firstName"
                  required
                  value={formData.firstName}
                  onChange={handleChange}
                  className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-brand-500 outline-none" 
                  placeholder="John" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Last Name</label>
                <input 
                  type="text" 
                  name="lastName"
                  required
                  value={formData.lastName}
                  onChange={handleChange}
                  className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-brand-500 outline-none" 
                  placeholder="Doe" 
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Email Address</label>
              <input 
                type="email" 
                name="email"
                required
                value={formData.email}
                onChange={handleChange}
                className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-brand-500 outline-none" 
                placeholder={APP_CONFIG.company.email}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Message</label>
              <textarea 
                rows={4} 
                name="message"
                required
                value={formData.message}
                onChange={handleChange}
                className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-brand-500 outline-none" 
                placeholder="Tell us about your project..."
              ></textarea>
            </div>

            <button 
              type="submit" 
              className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg hover:shadow-brand-500/25 flex items-center justify-center gap-2 group"
            >
              <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              Send Message
            </button>
          </form>

        </div>
      </div>
    </section>
  );
};

export default Contact;
