import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, Sparkles } from 'lucide-react';
import { ChatMessage } from '../types';
import { createChatSession, sendMessageToGemini } from '../services/geminiService';
import { Chat } from '@google/genai';
import { APP_CONFIG } from '../config';

const Consultant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize session and send intro message
    const initChat = async () => {
      const session = createChatSession();
      if (session) {
        setChatSession(session);
        setLoading(true);
        // Send a hidden prompt to trigger the first greeting from the system instruction
        const intro = await sendMessageToGemini(session, APP_CONFIG.aiConsultant.welcomeMessage);
        setMessages([
          {
            id: 'init',
            role: 'model',
            text: intro,
            timestamp: new Date()
          }
        ]);
        setLoading(false);
      } else {
        setMessages([{
          id: 'error',
          role: 'model',
          text: "System Alert: API Key missing or invalid. Please check your environment configuration to enable the AI Architect.",
          timestamp: new Date()
        }]);
      }
    };
    initChat();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !chatSession) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    const responseText = await sendMessageToGemini(chatSession, input);

    const modelMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, modelMsg]);
    setLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <section className="py-24 bg-[#0a0f1e] relative overflow-hidden">
      {/* Decorative bg elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand-900/10 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        
        {/* Left Side Content */}
        <div className="space-y-6">
          <div className="inline-flex items-center space-x-2 text-brand-400 font-semibold tracking-wide uppercase text-sm">
            <Sparkles className="w-4 h-4" />
            <span>Interactive Project Planner</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white leading-tight">
            Build Your Vision <br />
            <span className="text-gray-500">With AI Precision</span>
          </h2>
          <p className="text-lg text-gray-400">
            Not sure where to start? Our AI Architect "{APP_CONFIG.aiConsultant.name}" will ask you the relevant questions to define your project scope, features, and tech stack in minutes.
          </p>
          
          <ul className="space-y-4 pt-4">
            {[
              "Clarify your business goals",
              "Define your target audience",
              "Structure your feature wishlist",
              "Estimate project complexity"
            ].map((item, i) => (
              <li key={i} className="flex items-center space-x-3 text-gray-300">
                <div className="w-6 h-6 rounded-full bg-brand-900/50 flex items-center justify-center border border-brand-500/30">
                  <span className="text-brand-400 text-xs">✓</span>
                </div>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Right Side - Chat Interface */}
        <div className="bg-dark-800 border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[600px]">
          
          {/* Chat Header */}
          <div className="p-4 bg-dark-900 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 bg-brand-600 rounded-full flex items-center justify-center">
                  <Bot className="text-white w-6 h-6" />
                </div>
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-dark-900"></div>
              </div>
              <div>
                <h3 className="text-white font-bold">{APP_CONFIG.aiConsultant.name} Architect</h3>
                <p className="text-xs text-brand-400">Online | Ready to help</p>
              </div>
            </div>
            <button 
              onClick={() => {
                setMessages([]); 
                window.location.reload();
              }}
              className="text-xs text-gray-500 hover:text-white underline"
            >
              Reset Session
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-dark-800/50">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[85%] rounded-2xl p-4 ${
                    msg.role === 'user' 
                      ? 'bg-brand-600 text-white rounded-br-none' 
                      : 'bg-dark-700 text-gray-200 rounded-bl-none border border-white/5'
                  }`}
                >
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-dark-700 rounded-2xl rounded-bl-none p-4 border border-white/5 flex space-x-2 items-center">
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 bg-dark-900 border-t border-white/5">
            <div className="relative flex items-center">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Describe your project idea..."
                className="w-full bg-dark-800 text-white placeholder-gray-500 rounded-xl py-3 pl-4 pr-12 border border-white/10 focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none transition-all"
                disabled={loading}
              />
              <button 
                onClick={handleSend}
                disabled={loading || !input.trim()}
                className="absolute right-2 p-2 bg-brand-600 hover:bg-brand-500 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default Consultant;