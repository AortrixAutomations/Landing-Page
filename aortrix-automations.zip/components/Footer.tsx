import React from 'react';
import { Rocket, Twitter, Linkedin, Instagram } from 'lucide-react';
import { APP_CONFIG } from '../config';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-900 pt-16 pb-8 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
                <Rocket className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-white">
                {APP_CONFIG.company.logoText}<span className="text-brand-400">{APP_CONFIG.company.logoAccent}</span>
              </span>
            </div>
            <p className="text-gray-500 max-w-sm mb-6">
              Transforming ideas into digital reality through design, code, and artificial intelligence.
            </p>
            <div className="flex space-x-4">
              <a href={APP_CONFIG.company.social.twitter} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-600 hover:text-white transition-all">
                <Twitter className="w-5 h-5" />
              </a>
              <a href={APP_CONFIG.company.social.linkedin} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-600 hover:text-white transition-all">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href={APP_CONFIG.company.social.instagram} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-600 hover:text-white transition-all">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6">Company</h4>
            <ul className="space-y-4 text-gray-500">
              <li><a href="#" className="hover:text-brand-400 transition-colors">About</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Services</h4>
            <ul className="space-y-4 text-gray-500">
              <li><a href="#" className="hover:text-brand-400 transition-colors">Web Development</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">App Design</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">AI Consulting</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">SEO Growth</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-600 text-sm">© {new Date().getFullYear()} {APP_CONFIG.company.name}. All rights reserved.</p>
          <div className="flex items-center space-x-2 text-gray-600 text-sm">
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            <span>All systems operational</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;