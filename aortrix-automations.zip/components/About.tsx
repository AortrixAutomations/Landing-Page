import React from 'react';
import { APP_CONFIG } from '../config';

const About: React.FC = () => {
  return (
    <section className="py-24 bg-dark-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-brand-600 to-purple-600 rounded-2xl opacity-30 blur-lg"></div>
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop" 
                alt="Team collaborating" 
                className="relative rounded-2xl shadow-2xl border border-white/10 grayscale hover:grayscale-0 transition-all duration-500"
              />
            </div>
          </div>
          
          <div className="lg:w-1/2 space-y-8">
            <h2 className="text-3xl md:text-5xl font-bold text-white">
              We Craft Digital <br />
              <span className="text-brand-400">Masterpieces</span>
            </h2>
            <p className="text-gray-400 text-lg leading-relaxed">
              {APP_CONFIG.company.description}
            </p>
            
            <div className="grid grid-cols-3 gap-6 pt-4">
              <div>
                <div className="text-3xl font-bold text-white mb-2">{APP_CONFIG.stats.projects}</div>
                <div className="text-sm text-gray-500">Projects Delivered</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-2">{APP_CONFIG.stats.retention}</div>
                <div className="text-sm text-gray-500">Client Retention</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-2">{APP_CONFIG.stats.awards}</div>
                <div className="text-sm text-gray-500">Industry Awards</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;