import React from 'react';
import { Section } from '../types';
import { ArrowRight, Globe, Zap, Shield } from 'lucide-react';
import { APP_CONFIG } from '../config';

interface HeroProps {
  scrollToSection: (section: Section) => void;
}

const Hero: React.FC<HeroProps> = ({ scrollToSection }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden bg-gradient-to-b from-dark-900 via-[#0a0f1e] to-dark-900">
      
      {/* Background Blobs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-40">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-32 left-1/3 w-96 h-96 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10 flex flex-col md:flex-row items-center">
        
        {/* Text Content */}
        <div className="md:w-1/2 text-left space-y-8 animate-fade-in">
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 backdrop-blur-sm">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
            </span>
            <span className="text-xs font-medium text-brand-300 tracking-wide uppercase">Accepting New Clients</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold text-white leading-tight tracking-tight">
            {APP_CONFIG.company.heroHeadline} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 via-purple-400 to-pink-400">
              {APP_CONFIG.company.tagline}
            </span>
          </h1>

          <p className="text-lg md:text-xl text-gray-400 max-w-xl leading-relaxed">
            {APP_CONFIG.company.description}
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => scrollToSection(Section.CONSULTANT)}
              className="px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white rounded-xl font-bold text-lg transition-all shadow-[0_0_20px_rgba(2,132,199,0.3)] hover:shadow-[0_0_30px_rgba(2,132,199,0.5)] flex items-center justify-center gap-2"
            >
              Consult AI Architect <ArrowRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => scrollToSection(Section.SERVICES)}
              className="px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-xl font-bold text-lg transition-all backdrop-blur-sm"
            >
              Explore Services
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="pt-8 flex items-center gap-8 text-gray-500 border-t border-white/5">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5" /> 
              <span className="text-sm">Global Reach</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5" /> 
              <span className="text-sm">Lightning Fast</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5" /> 
              <span className="text-sm">Enterprise Secure</span>
            </div>
          </div>
        </div>

        {/* Graphic / Visual */}
        <div className="md:w-1/2 mt-16 md:mt-0 relative">
          <div className="relative w-full h-[400px] md:h-[600px] bg-gradient-to-tr from-brand-500/10 to-purple-500/10 rounded-2xl border border-white/10 backdrop-blur-sm overflow-hidden flex items-center justify-center group">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop')] bg-cover bg-center opacity-40 mix-blend-overlay transition-transform duration-700 group-hover:scale-105"></div>
            
            {/* Floating Card */}
            <div className="relative p-6 bg-dark-800/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl max-w-xs transform transition-all duration-500 hover:-translate-y-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-brand-600 flex items-center justify-center">
                  <span className="font-bold text-white">AI</span>
                </div>
                <div>
                  <div className="text-sm font-bold text-white">Project Analysis</div>
                  <div className="text-xs text-brand-400">Processing Requirements...</div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-2 bg-white/10 rounded w-3/4"></div>
                <div className="h-2 bg-white/10 rounded w-1/2"></div>
                <div className="h-2 bg-white/10 rounded w-full"></div>
              </div>
              <div className="mt-4 flex justify-between items-center">
                <div className="text-xs text-gray-400">Efficiency</div>
                <div className="text-xs font-bold text-green-400">+145%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;